"""Continuous plant with piecewise-linear inputs; streaming Welch estimator."""

import math

import numpy as np
from scipy import fft, signal


class FOHPlant:
    """Advance model1019 using first-order hold, preserving state across blocks.

    Inputs are [six actuator commands, six SI base displacements].
    Default physical initial state X(0)=0 is converted to the exported state Z.
    """

    def __init__(self, model, fs, first_input):
        self.poles, vectors = np.linalg.eig(model["A"])
        self.drive = np.linalg.solve(vectors, model["B"])
        self.output = model["C"] @ vectors
        self.direct = model["D"]
        z = self.poles / fs
        # Entire-function series avoid cancellation for the slowest poles.
        p1 = np.polynomial.polynomial.polyval(z, [1 / math.factorial(k + 1) for k in range(18)]) / fs
        p2 = np.polynomial.polynomial.polyval(z, [1 / math.factorial(k + 2) for k in range(18)]) / fs
        self.poles = np.exp(z)
        self.numerators = np.column_stack((p2, p1 - p2))
        z0 = -model["state_recovery_J_si"] @ first_input[6:12]
        self.delay = np.linalg.solve(vectors, z0) - p2 * (self.drive @ first_input)

    def process(self, inputs):
        """inputs [block_samples,12] -> clean measured velocity [block_samples,6]."""
        drive = self.drive @ inputs.T
        states = np.empty_like(drive)
        for mode in range(len(self.poles)):
            states[mode], delay = signal.lfilter(
                self.numerators[mode], [1, -self.poles[mode]], drive[mode], zi=[self.delay[mode]])
            self.delay[mode] = delay[0]
        return (self.output @ states + self.direct @ inputs.T).real.T


class WelchAccumulator:
    """Periodic Hann, 50% overlap, per-segment constant detrend, density, mean."""

    def __init__(self, channels=24, fs=10000, nperseg=1000000):
        self.fs, self.nperseg = fs, nperseg
        self.hop = nperseg // 2
        self.window = 0.5 - 0.5 * np.cos(2 * np.pi * np.arange(nperseg) / nperseg)
        all_f = fft.rfftfreq(nperseg, 1 / fs)
        self.keep = all_f <= 100
        self.frequency = all_f[self.keep]
        self.scale = fs * np.sum(self.window ** 2)
        self.buffer = np.empty((nperseg, channels))
        self.total = np.zeros((len(self.frequency), channels))
        self.filled, self.segments = 0, 0

    def push(self, values):
        offset = 0
        while offset < len(values):
            count = min(self.nperseg - self.filled, len(values) - offset)
            self.buffer[self.filled:self.filled + count] = values[offset:offset + count]
            self.filled += count
            offset += count
            if self.filled == self.nperseg:
                for axis in range(self.buffer.shape[1]):
                    column = self.buffer[:, axis]
                    spectrum = fft.rfft((column - column.mean()) * self.window)
                    p = np.abs(spectrum) ** 2 / self.scale
                    p[1:-1] *= 2  # nperseg is even: DC and Nyquist are not doubled.
                    self.total[:, axis] += p[self.keep]
                self.segments += 1
                self.buffer[:self.hop] = self.buffer[self.hop:].copy()
                self.filled = self.hop

    def result(self):
        if not self.segments:
            raise ValueError("At least 100 seconds are required for the fixed Welch segment")
        return self.frequency.copy(), self.total / self.segments


def displacement_asds(f, psd):
    """Columns: ground, clean output, noise, measured output, six axes each."""
    asd = np.sqrt(np.maximum(psd, 0))
    asd[:, 6:] /= 2 * np.pi * f[:, None] + 1e-30
    return asd


def plot_asds(f, asd, destination, duration, segments):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    keep = (f >= 0.01) & (f <= 100) & (f > 0)
    labels = ["x", "y", "z", "theta_x", "theta_y", "theta_z"]
    names = ["Ground motion", "Clean output", "Sensor noise", "Measured output"]
    colors = ["#c65b36", "#536878", "#7954a1", "#1559a6"]
    styles = ["--", ":", "--", "-"]
    fig, axes = plt.subplots(2, 3, figsize=(13.2, 8.4))
    for axis, ax in enumerate(axes.flat):
        values = asd[keep][:, axis + 6 * np.arange(4)]
        for group in range(4):
            ax.loglog(f[keep], values[:, group], label=names[group], color=colors[group], ls=styles[group], lw=1.1)
        positive = values[np.isfinite(values) & (values > 0)]
        lo, hi = np.log10([positive.min(), positive.max()])
        margin = 0.08 * (hi - lo)
        ax.set(xlim=(0.01, 100), ylim=(10 ** (lo - margin), 10 ** (hi + margin)),
               title=labels[axis], xlabel="Frequency [Hz]",
               ylabel="ASD [m/√Hz]" if axis < 3 else "ASD [rad/√Hz]")
        ax.grid(True, which="both", alpha=0.18)
    fig.suptitle(f"Activity enhanced | no control | 10 kHz, {duration:g} s", fontsize=16)
    handles, legend = axes[0, 0].get_legend_handles_labels()
    fig.legend(handles, legend, loc="lower center", bbox_to_anchor=(0.5, 0.045), ncol=4, frameon=False)
    fig.text(0.5, 0.016, f"Welch: periodic Hann, 1,000,000 samples, 50% overlap, constant detrend, density, mean | {segments} segments",
             ha="center", fontsize=9)
    fig.tight_layout(rect=(0, 0.105, 1, 0.95))
    fig.savefig(destination, dpi=180)
    plt.close(fig)
