"""No-control example: Activity enhanced -> model1019 -> output sensor noise.

Run from any working directory: python /path/to/python/run_example.py
No controller is included. Time histories are not saved to disk.
"""

import argparse
import json
import time
from pathlib import Path

import numpy as np
from scipy import io

from simulation import FOHPlant, WelchAccumulator, displacement_asds, plot_asds
from sources import activity_motion, sensor_noise

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--duration", type=float, default=1000, help="seconds; default 1000, minimum 100")
    parser.add_argument("--ground-seed", type=int, default=1024)
    parser.add_argument("--noise-seed", type=int, default=20260114)
    parser.add_argument("--output", type=Path, default=ROOT / "outputs" / "python")
    args = parser.parse_args()
    fs, block = 10000, 100000
    if args.duration < 100 or not np.isclose(fs * args.duration, round(fs * args.duration)):
        parser.error("duration must be at least 100 s and give an integer sample count")
    started = time.perf_counter()
    model = io.loadmat(ROOT / "data" / "model1019.mat", simplify_cells=True)
    b_si = activity_motion(fs, args.duration, args.ground_seed)
    n_si = sensor_noise(fs, args.duration, args.noise_seed)
    first_input = np.r_[np.zeros(6), b_si[0]]
    plant = FOHPlant(model, fs, first_input)
    welch = WelchAccumulator()
    for start in range(0, len(b_si), block):
        stop = min(start + block, len(b_si))
        base, noise = b_si[start:stop], n_si[start:stop]
        # The first six inputs are actuator commands, fixed at zero.
        inputs = np.column_stack((np.zeros_like(base), base))
        clean = plant.process(inputs)
        measured = clean + noise
        welch.push(np.column_stack((base, clean, noise, measured)))
        if stop % 1000000 == 0 or stop == len(b_si):
            print(f"Simulation and spectra: {stop / fs:g}/{args.duration:g} s", flush=True)
    f, psd = welch.result()
    asd = displacement_asds(f, psd)
    args.output.mkdir(parents=True, exist_ok=True)
    io.savemat(args.output / "spectra.mat", {
        "frequency_hz": f[:, None], "psd": psd, "asd": asd,
        "group_order": np.array(["ground", "clean", "noise", "measured"], dtype=object),
        "channel_order": np.array(["x", "y", "z", "theta_x", "theta_y", "theta_z"], dtype=object),
        "welch_segment_count": welch.segments,
    }, do_compression=True)
    metadata = {"scenario": "Activity enhanced", "fs_hz": fs, "duration_s": args.duration,
                "samples": len(b_si), "reference_length_m": float(model["reference_length_m"]),
                "ground_seed": args.ground_seed, "noise_seed": args.noise_seed,
                "nperseg": 1000000, "noverlap": 500000, "nfft": 1000000,
                "window": "periodic Hann", "detrend": "constant per segment",
                "scaling": "density", "average": "mean", "one_sided": True,
                "welch_segments": welch.segments, "discarded_startup_seconds": 0,
                "actuator_commands": "all zero", "physical_initial_state": "all zero",
                "time_histories_saved": False, "elapsed_seconds": time.perf_counter() - started}
    (args.output / "run_info.json").write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    plot_asds(f, asd, args.output / "asd_comparison.png", args.duration, welch.segments)
    print(f"Saved spectra, ASD figure and run settings to {args.output}", flush=True)


if __name__ == "__main__":
    main()
