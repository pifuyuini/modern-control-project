"""Activity enhanced ground displacement and independent sensor noise.

Public time histories have shape (samples, 6), ordered x, y, z, rx, ry, rz.
Ground is in m / rad. Sensor noise is returned in m/s / rad/s.
"""

from pathlib import Path

import numpy as np
from scipy import fft, io

DATA = Path(__file__).resolve().parents[1] / "data"
FREQUENCY_BLOCK = 16384


def load_source():
    return io.loadmat(DATA / "activity_source.mat", simplify_cells=True)


def power_taper(f, band):
    lo, lp, hp, hi = band
    w = np.zeros_like(f)
    w[(f >= lp) & (f <= hp)] = 1.0
    left = (f > lo) & (f < lp)
    right = (f > hp) & (f < hi)
    w[left] = np.sin(np.pi / 2 * (f[left] - lo) / (lp - lo)) ** 2
    w[right] = np.cos(np.pi / 2 * (f[right] - hp) / (hi - hp)) ** 2
    return w


def vertical_psd(f, source):
    """One-sided vertical displacement PSD, including the power taper."""
    band = power_taper(f, source["band_hz"])
    active = band > 0
    result = np.zeros_like(f)
    x = f[active]
    anchor = float(source["anchor_hz"])
    ref = source["reference_table"]
    log_period = np.log10(1 / np.minimum(x, anchor))
    low = np.interp(log_period, np.log10(ref[:, 0]), ref[:, 1])
    high = np.interp(log_period, np.log10(ref[:, 0]), ref[:, 2])
    mix = float(source["background_mix"])
    level = (1 - mix) * low + mix * high + float(source["background_offset_db"])
    extension = np.maximum(x / anchor, 1.0) ** float(source["acceleration_psd_exponent"])
    result[active] = 10 ** (level / 10) * extension / (2 * np.pi * x) ** 4
    return result * band


def spectral_factors(f, source):
    """Yield group and h(f), with S(f)=sum(h(f) h(f)^H)."""
    pz = vertical_psd(f, source)
    angles = np.arange(int(source["direction_count"])) * 2 * np.pi / int(source["direction_count"])
    parameters = [source["rayleigh"], source["love"]]
    weights, speeds = [], []
    for par in parameters:
        # [c_low, c_high, corner, exponent, isotropic_fraction, azimuth_deg, concentration]
        cl, ch, corner, exponent, isotropic, azimuth, concentration = par
        lobe = np.exp(concentration * (np.cos(angles - np.deg2rad(azimuth)) - 1))
        weights.append(isotropic / len(angles) + (1 - isotropic) * lobe / lobe.sum())
        speeds.append(ch + (cl - ch) / (1 + (f / corner) ** exponent))
    kr, kl = 2 * np.pi * f / speeds[0], 2 * np.pi * f / speeds[1]
    for i, angle in enumerate(angles):
        co, si = np.cos(angle), np.sin(angle)
        hr, hl = np.zeros((len(f), 6), complex), np.zeros((len(f), 6), complex)
        ellipticity = float(source["ellipticity"])
        hr[:, 0], hr[:, 1], hr[:, 2] = 1j * ellipticity * co, 1j * ellipticity * si, 1
        hr[:, 3], hr[:, 4] = -1j * kr * si, 1j * kr * co
        hl[:, 0], hl[:, 1], hl[:, 5] = -si, co, -1j * kl / 2
        yield 0, hr * np.sqrt(pz * weights[0][i])[:, None]
        yield 0, hl * np.sqrt(pz * weights[1][i] * float(source["love_power_ratio"]))[:, None]
    for i, kind in enumerate(np.atleast_1d(source["local_kind"])):
        f0 = source["local_frequency_hz"][i]
        if kind == 0:
            damping = source["local_damping_ratio"][i]
            shape = 1 / ((f0 * f0 - f * f) ** 2 + (2 * damping * f0 * f) ** 2)
        else:
            shape = 1 / (1 + (f / f0) ** 4)
        shape *= power_taper(f, source["band_hz"]) / source["local_normalization"][i]
        yield 1, np.sqrt(shape)[:, None] * source["local_pose_rms_si"][:, i]


def _real_record(coefficients, samples):
    """coefficients = Q[k]/N at nonnegative frequencies; DC is zero."""
    spectrum = np.zeros(samples // 2 + 1, complex)
    spectrum[:len(coefficients)] = samples * coefficients
    return fft.irfft(spectrum, n=samples, workers=1)


def activity_motion(fs=10000, duration=1000, seed=1024):
    """Generate only the fixed Activity enhanced scenario; return b_SI [N,6]."""
    source = load_source()
    n = round(fs * duration)
    if fs / 2 <= float(source["band_hz"][-1]):
        raise ValueError("fs/2 must exceed the 1250 Hz source stop edge")
    if n < 2 or not np.isclose(n, fs * duration):
        raise ValueError("fs*duration must be a positive integer sample count")
    df = fs / n
    count = int(np.floor(float(source["band_hz"][-1]) / df)) + 1
    coefficients = np.zeros((2, 6, count), complex)
    rng = np.random.default_rng(seed)
    for start in range(0, count, FREQUENCY_BLOCK):
        stop = min(start + FREQUENCY_BLOCK, count)
        f = np.arange(start, stop) * df
        for group, factor in spectral_factors(f, source):
            z = (rng.standard_normal(len(f)) + 1j * rng.standard_normal(len(f))) / np.sqrt(2)
            coefficients[group, :, start:stop] += (np.sqrt(df / 2) * factor * z[:, None]).T
    print("Activity enhanced: random spectra generated", flush=True)
    b = np.zeros((n, 6))
    block = 100000
    for group in range(2):
        depth, period, phase = source["modulation"][group]
        for axis in range(6):
            waveform = _real_record(coefficients[group, axis], n)
            for start in range(0, n, block):
                stop = min(start + block, n)
                t = np.arange(start, stop) / fs
                envelope = 1 + depth * np.sin(2 * np.pi * t / period + phase)
                b[start:stop, axis] += envelope * waveform[start:stop]
        print(f"Activity enhanced: random group {group + 1}/2 complete", flush=True)
    # Small deterministic components are evaluated in blocks to limit memory.
    for start in range(0, n, block):
        stop = min(start + block, n)
        t = np.arange(start, stop) / fs
        for par, pose in zip(np.atleast_2d(source["tone_parameters"]), np.atleast_2d(source["tone_pose_rms_si"])):
            f0, drift, period, phase0 = par
            wm = 2 * np.pi / period
            phase = phase0 + 2 * np.pi * f0 * t + 2 * np.pi * drift / wm * (1 - np.cos(wm * t))
            b[start:stop] += np.cos(phase)[:, None] * (np.sqrt(2) * pose)
        for par, pose in zip(np.atleast_2d(source["event_parameters"]), np.atleast_2d(source["event_pose_peak_si"])):
            centre, width, carrier = par
            tau = t - centre
            packet = np.exp(-0.5 * (tau / width) ** 2) * np.cos(2 * np.pi * carrier * tau)
            b[start:stop] += packet[:, None] * pose
    return b


def sensor_noise(fs=10000, duration=1000, seed=20260114):
    """Generate six independent velocity-equivalent noises and convert to SI."""
    table = np.loadtxt(DATA / "sensor_noise_psd.csv", delimiter=",", skiprows=1)
    n = round(fs * duration)
    df = fs / n
    f = np.arange(int(np.floor(1000 / df)) + 1) * df
    psd = np.zeros_like(f)
    keep = (f >= 0.001) & (f <= 1000)
    psd[keep] = np.exp(np.interp(np.log(f[keep]), np.log(table[:, 0]), np.log(table[:, 1])))
    noise = np.empty((n, 6))
    streams = np.random.SeedSequence(seed).spawn(6)
    for axis, stream in enumerate(streams):
        rng = np.random.default_rng(stream)
        z = (rng.standard_normal(len(f)) + 1j * rng.standard_normal(len(f))) / np.sqrt(2)
        noise[:, axis] = _real_record(np.sqrt(psd * df / 2) * z, n)
        if axis >= 3:
            noise[:, axis] /= 0.71177  # Fixed supplied reference radius, in metres.
        print(f"Sensor noise: channel {axis + 1}/6", flush=True)
    return noise
