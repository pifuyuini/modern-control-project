# Model1019 大作业教学包

版本 1.0 · 2026-11-05

本包提供带六路基座扰动输入的连续时间状态空间模型、固定 Activity enhanced 宽频地面源、传感噪声谱，以及 Python 与 MATLAB 两套独立示例。示例均为无控制系统，六路执行器命令固定为零；不包含控制器。

模型外部接口直接使用 SI 单位，转动通道的尺度换算已在包内完成，调用方无需额外进行长度缩放。

## 使用手册

使用手册已移至课程网站，不再包含在压缩包内。

- [在线使用手册](https://pifuyuini.github.io/modern-control-project/docs/)：浏览器直接打开，可打印或另存为 PDF。
- [使用手册 Markdown](https://pifuyuini.github.io/modern-control-project/docs/USER_GUIDE.md)：与在线手册对应的文本版本。
- [包信息](PACKAGE_INFO.json)：版本、固定参数、导出环境与文件来源。

## Python 入口

在已准备好 NumPy、SciPy、Matplotlib 的 Python 3.10 或更高版本环境中，从解压目录执行：

```sh
python python/run_example.py
```

运行依赖列于 `python/requirements.txt`。示例不会自动安装依赖。

## MATLAB 入口

在 MATLAB 中切换到解压目录后执行：

```matlab
addpath(fullfile(pwd,'matlab'));
run_example;
```

代码采用 MATLAB R2019a 或更新版本提供的基础函数，主示例不调用 Control System Toolbox 或 Signal Processing Toolbox。

## 默认设置与输出

- 采样率 10000 Hz，记录时长 1000 s；源目标通带 0.001–1000 Hz。
- 地面源输出 m／rad，模型与噪声输出 m/s／rad/s。
- Welch：周期 Hann、1000000 点、50% 重叠、逐段去均值、density、mean。
- 六幅 ASD 子图：0.01–100 Hz；平移 m/√Hz，转动 rad/√Hz。
- 结果写入 `outputs/python/` 或 `outputs/matlab/`，包括 `spectra.mat`、`asd_comparison.png`、`run_info.json`。
- 不保存大体积时程；相同输出目录中的同名结果会被覆盖。

本版本完成代码与接口静态审阅，未执行两套示例、仿真或数值校验。包内没有预生成的仿真结果，也没有校验程序。
