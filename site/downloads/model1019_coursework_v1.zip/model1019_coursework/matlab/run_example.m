function run_example(duration_s,ground_seed,noise_seed,output_dir)
%RUN_EXAMPLE No control: ground displacement -> model -> output sensor noise.
% Default: 10 kHz, 1000 s. No time histories are written to disk.
% Add this matlab/ folder to the MATLAB path, then call run_example.
root = fileparts(fileparts(mfilename('fullpath')));
if nargin<1, duration_s = 1000; end
if nargin<2, ground_seed = 1024; end
if nargin<3, noise_seed = 20260114; end
if nargin<4, output_dir = fullfile(root,'outputs','matlab'); end
fs = 10000; block = 100000;
if duration_s<100 || abs(fs*duration_s-round(fs*duration_s))>1e-6
    error('duration_s must be >=100 and fs*duration_s an integer.');
end
started = tic;
M = load(fullfile(root,'data','model1019.mat'));
b_si = activity_motion(fs,duration_s,ground_seed);
n_si = sensor_noise(fs,duration_s,noise_seed);
plant = FOHPlant(M,fs,[zeros(1,6),b_si(1,:)]);
welch = WelchAccumulator(24,fs,1000000);
n = size(b_si,1);
for first = 1:block:n
    last = min(first+block-1,n);
    base = b_si(first:last,:);
    noise = n_si(first:last,:);
    inputs = [zeros(size(base)),base]; % Six actuator commands fixed at zero.
    clean = plant.process(inputs);
    measured = clean+noise;
    welch.push([base,clean,noise,measured]);
    if mod(last,1000000)==0 || last==n
        fprintf('Simulation and spectra: %g/%g s\n',last/fs,duration_s);
    end
end
[frequency_hz,psd] = welch.result();
asd = sqrt(max(psd,0));
asd(:,7:24) = asd(:,7:24)./(2*pi*frequency_hz+1e-30);
group_order = {'ground','clean','noise','measured'};
channel_order = {'x','y','z','theta_x','theta_y','theta_z'};
welch_segment_count = welch.segments;
if ~exist(output_dir,'dir'), mkdir(output_dir); end
save(fullfile(output_dir,'spectra.mat'),'frequency_hz','psd','asd', ...
    'group_order','channel_order','welch_segment_count','-v7');
info = struct('scenario','Activity enhanced','fs_hz',fs, ...
    'duration_s',duration_s,'samples',n,'reference_length_m',M.reference_length_m, ...
    'ground_seed',ground_seed,'noise_seed',noise_seed, ...
    'nperseg',1000000,'noverlap',500000,'nfft',1000000, ...
    'window','periodic Hann','detrend','constant per segment', ...
    'scaling','density','average','mean','one_sided',true, ...
    'welch_segments',welch.segments,'discarded_startup_seconds',0, ...
    'actuator_commands','all zero','physical_initial_state','all zero', ...
    'time_histories_saved',false,'elapsed_seconds',toc(started));
fid = fopen(fullfile(output_dir,'run_info.json'),'w','n','UTF-8');
if fid<0, error('Cannot write run_info.json.'); end
cleanup = onCleanup(@() fclose(fid));
fprintf(fid,'%s\n',jsonencode(info));
clear cleanup;
plot_asds(frequency_hz,asd,fullfile(output_dir,'asd_comparison.png'),duration_s,welch.segments);
fprintf('Saved spectra, ASD figure and run settings to %s\n',output_dir);
end
