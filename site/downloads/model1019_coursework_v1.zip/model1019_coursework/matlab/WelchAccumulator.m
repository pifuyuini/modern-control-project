classdef WelchAccumulator < handle
    %WELCHACCUMULATOR Explicit Welch definition; no Signal Processing Toolbox.
    % Periodic Hann, 50% overlap, per-segment mean removal, one-sided density.
    properties (SetAccess=private)
        frequency
        segments = 0
    end
    properties (Access=private)
        nperseg
        hop
        window
        scale
        keep
        buffer
        filled = 0
        total
    end
    methods
        function obj = WelchAccumulator(channels,fs,nperseg)
            obj.nperseg = nperseg;
            obj.hop = nperseg/2;
            obj.window = 0.5-0.5*cos(2*pi*(0:nperseg-1)'/nperseg);
            f = (0:nperseg/2)'*fs/nperseg;
            obj.keep = f<=100;
            obj.frequency = f(obj.keep);
            obj.scale = fs*sum(obj.window.^2);
            obj.buffer = zeros(nperseg,channels);
            obj.total = zeros(numel(obj.frequency),channels);
        end
        function push(obj,values)
            offset = 0;
            while offset<size(values,1)
                count = min(obj.nperseg-obj.filled,size(values,1)-offset);
                obj.buffer(obj.filled+(1:count),:) = values(offset+(1:count),:);
                obj.filled = obj.filled+count;
                offset = offset+count;
                if obj.filled==obj.nperseg
                    for k = 1:size(obj.buffer,2)
                        column = obj.buffer(:,k);
                        spectrum = fft((column-mean(column)).*obj.window);
                        p = abs(spectrum(1:obj.nperseg/2+1)).^2/obj.scale;
                        p(2:end-1) = 2*p(2:end-1);
                        obj.total(:,k) = obj.total(:,k)+p(obj.keep);
                    end
                    obj.segments = obj.segments+1;
                    obj.buffer(1:obj.hop,:) = obj.buffer(obj.hop+1:end,:);
                    obj.filled = obj.hop;
                end
            end
        end
        function [frequency,psd] = result(obj)
            if obj.segments==0
                error('At least 100 seconds are required for a complete Welch segment.');
            end
            frequency = obj.frequency;
            psd = obj.total/obj.segments;
        end
    end
end
