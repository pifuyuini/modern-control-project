function n_si = sensor_noise(fs, duration_s, seed)
%SENSOR_NOISE Six independent noises; output [N,6] in m/s,rad/s.
% The table P_ns is a one-sided velocity-equivalent PSD in (m/s)^2/Hz.
if nargin < 1, fs = 10000; end
if nargin < 2, duration_s = 1000; end
if nargin < 3, seed = 20260114; end
root = fileparts(fileparts(mfilename('fullpath')));
table = readmatrix(fullfile(root,'data','sensor_noise_psd.csv'),'NumHeaderLines',1);
n = round(fs*duration_s);
df = fs/n;
f = (0:floor(1000/df))'*df;
p = zeros(size(f));
keep = f>=0.001 & f<=1000;
p(keep) = exp(interp1(log(table(:,1)),log(table(:,2)),log(f(keep)),'linear'));
n_si = zeros(n,6);
% Distinct draws from a local stream; independent of the ground-motion stream.
stream = RandStream('mt19937ar','Seed',seed);
for axis = 1:6
    z = (randn(stream,numel(f),1)+1i*randn(stream,numel(f),1))/sqrt(2);
    n_si(:,axis) = real_record(sqrt(p*df/2).*z,n);
    if axis>=4
        n_si(:,axis) = n_si(:,axis)/0.71177; % Fixed supplied radius, in metres.
    end
    fprintf('Sensor noise: channel %d/6\n',axis);
end
end
