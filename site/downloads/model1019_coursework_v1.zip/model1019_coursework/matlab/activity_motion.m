function b_si = activity_motion(fs, duration_s, seed)
%ACTIVITY_MOTION Fixed Activity enhanced source, output [N,6] in m/rad.
% Order: x, y, z, theta_x, theta_y, theta_z. Requires base MATLAB only.
if nargin < 1, fs = 10000; end
if nargin < 2, duration_s = 1000; end
if nargin < 3, seed = 1024; end
root = fileparts(fileparts(mfilename('fullpath')));
S = load(fullfile(root, 'data', 'activity_source.mat'));
n = round(fs * duration_s);
if fs/2 <= S.band_hz(4) || n < 2 || abs(n-fs*duration_s) > 1e-6
    error('Require integer fs*duration and fs/2 > 1250 Hz.');
end
df = fs/n;
count = floor(S.band_hz(4)/df)+1;
coeff = complex(zeros(count, 6, 2)); % Q[k]/N for background and local groups
stream = RandStream('mt19937ar', 'Seed', seed);
angles = (0:S.direction_count-1)' * 2*pi/S.direction_count;
wr = angular_weights(angles, S.rayleigh);
wl = angular_weights(angles, S.love);
for first = 1:16384:count
    last = min(first+16383, count);
    idx = first:last;
    f = (idx'-1)*df;
    pz = vertical_psd(f, S);
    kr = 2*pi*f ./ phase_speed(f, S.rayleigh);
    kl = 2*pi*f ./ phase_speed(f, S.love);
    total = complex(zeros(numel(f),6,2));
    for k = 1:numel(angles)
        co = cos(angles(k)); si = sin(angles(k));
        hr = complex(zeros(numel(f),6));
        hl = complex(zeros(numel(f),6));
        hr(:,1) = 1i*S.ellipticity*co;
        hr(:,2) = 1i*S.ellipticity*si;
        hr(:,3) = 1;
        hr(:,4) = -1i*kr*si;
        hr(:,5) = 1i*kr*co;
        hl(:,1) = -si; hl(:,2) = co; hl(:,6) = -1i*kl/2;
        total(:,:,1) = total(:,:,1) + random_factor(hr .* sqrt(pz*wr(k)), df, stream);
        total(:,:,1) = total(:,:,1) + random_factor(hl .* sqrt(pz*wl(k)*S.love_power_ratio), df, stream);
    end
    for k = 1:numel(S.local_kind)
        f0 = S.local_frequency_hz(k);
        if S.local_kind(k) == 0
            shape = 1 ./ ((f0^2-f.^2).^2 + (2*S.local_damping_ratio(k)*f0*f).^2);
        else
            shape = 1 ./ (1+(f/f0).^4);
        end
        shape = shape .* power_taper(f, S.band_hz) / S.local_normalization(k);
        factor = sqrt(shape) * S.local_pose_rms_si(:,k).';
        total(:,:,2) = total(:,:,2) + random_factor(factor, df, stream);
    end
    coeff(idx,:,:) = total;
end
fprintf('Activity enhanced: random spectra generated\n');
b_si = zeros(n,6);
block = 100000;
for group = 1:2
    depth = S.modulation(group,1);
    period = S.modulation(group,2);
    phase = S.modulation(group,3);
    for axis = 1:6
        waveform = real_record(coeff(:,axis,group), n);
        for first = 1:block:n
            last = min(first+block-1,n);
            t = ((first:last)'-1)/fs;
            env = 1+depth*sin(2*pi*t/period+phase);
            b_si(first:last,axis) = b_si(first:last,axis)+env.*waveform(first:last);
        end
    end
    fprintf('Activity enhanced: random group %d/2 complete\n', group);
end
clear coeff waveform;
for first = 1:block:n
    last = min(first+block-1,n);
    t = ((first:last)'-1)/fs;
    for k = 1:size(S.tone_parameters,1)
        par = S.tone_parameters(k,:);
        wm = 2*pi/par(3);
        phase = par(4)+2*pi*par(1)*t+2*pi*par(2)/wm*(1-cos(wm*t));
        b_si(first:last,:) = b_si(first:last,:) + cos(phase)*(sqrt(2)*S.tone_pose_rms_si(k,:));
    end
    for k = 1:size(S.event_parameters,1)
        par = S.event_parameters(k,:);
        tau = t-par(1);
        packet = exp(-0.5*(tau/par(2)).^2).*cos(2*pi*par(3)*tau);
        b_si(first:last,:) = b_si(first:last,:) + packet*S.event_pose_peak_si(k,:);
    end
end
end

function x = random_factor(h, df, stream)
z = (randn(stream,size(h,1),1)+1i*randn(stream,size(h,1),1))/sqrt(2);
x = sqrt(df/2)*h.*z;
end

function c = phase_speed(f, p)
c = p(2)+(p(1)-p(2))./(1+(f/p(3)).^p(4));
end

function w = angular_weights(angles, p)
lobe = exp(p(7)*(cos(angles-p(6)*pi/180)-1));
w = p(5)/numel(angles)+(1-p(5))*lobe/sum(lobe);
end

function w = power_taper(f, band)
w = zeros(size(f));
w(f>=band(2) & f<=band(3)) = 1;
left = f>band(1) & f<band(2);
right = f>band(3) & f<band(4);
w(left) = sin(pi/2*(f(left)-band(1))/(band(2)-band(1))).^2;
w(right) = cos(pi/2*(f(right)-band(3))/(band(4)-band(3))).^2;
end

function pz = vertical_psd(f, S)
weight = power_taper(f,S.band_hz);
keep = weight>0;
x = f(keep);
period = log10(1./min(x,S.anchor_hz));
ref = S.reference_table;
lo = interp1(log10(ref(:,1)),ref(:,2),period,'linear');
hi = interp1(log10(ref(:,1)),ref(:,3),period,'linear');
level = (1-S.background_mix)*lo+S.background_mix*hi+S.background_offset_db;
extension = max(x/S.anchor_hz,1).^S.acceleration_psd_exponent;
pz = zeros(size(f));
pz(keep) = 10.^(level/10).*extension./(2*pi*x).^4;
pz = pz.*weight;
end
