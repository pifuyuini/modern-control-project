classdef FOHPlant < handle
    %FOHPLANT Continuous A/B/C/D plant, first-order-hold inputs, block state.
    % Inputs [N,12]: actuator commands then SI base displacement.
    properties (Access=private)
        poles
        drive
        output
        direct
        numerators
        delay
    end
    methods
        function obj = FOHPlant(M,fs,first_input)
            [V,E] = eig(M.A);
            z = diag(E)/fs;
            obj.poles = exp(z);
            obj.drive = V\M.B;
            obj.output = M.C*V;
            obj.direct = M.D;
            p1 = zeros(size(z)); p2 = zeros(size(z));
            for k = 0:17
                p1 = p1+z.^k/factorial(k+1)/fs;
                p2 = p2+z.^k/factorial(k+2)/fs;
            end
            obj.numerators = [p2,p1-p2];
            u0 = first_input(:);
            z0 = -M.state_recovery_J_si*u0(7:12);
            obj.delay = V\z0-p2.*(obj.drive*u0);
        end
        function clean = process(obj,inputs)
            drive_values = obj.drive*inputs.';
            states = complex(zeros(size(drive_values)));
            for k = 1:numel(obj.poles)
                [states(k,:),obj.delay(k)] = filter(obj.numerators(k,:), ...
                    [1,-obj.poles(k)],drive_values(k,:),obj.delay(k),2);
            end
            clean = real((obj.output*states+obj.direct*inputs.').');
        end
    end
end
