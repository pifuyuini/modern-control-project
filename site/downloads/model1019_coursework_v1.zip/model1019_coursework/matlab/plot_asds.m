function plot_asds(f,asd,destination,duration_s,segments)
%PLOT_ASDS Six panels, 0.01-100 Hz, 8%% padding in logarithmic y coordinates.
keep = f>=0.01 & f<=100 & f>0;
channels = {'x','y','z','theta_x','theta_y','theta_z'};
names = {'Ground motion','Clean output','Sensor noise','Measured output'};
colors = [0.776,0.357,0.212; 0.325,0.408,0.471; 0.475,0.329,0.631; 0.082,0.349,0.651];
styles = {'--',':','--','-'};
fig = figure('Color','w','Visible','off','Position',[100,100,1320,840]);
for axis = 1:6
    subplot(2,3,axis);
    values = asd(keep,axis+6*(0:3));
    hold on;
    for group = 1:4
        loglog(f(keep),values(:,group),'Color',colors(group,:), ...
            'LineStyle',styles{group},'LineWidth',1.1,'DisplayName',names{group});
    end
    set(gca,'XScale','log','YScale','log');
    positive = values(isfinite(values) & values>0);
    bounds = log10([min(positive),max(positive)]);
    margin = 0.08*diff(bounds);
    xlim([0.01,100]); ylim(10.^[bounds(1)-margin,bounds(2)+margin]);
    title(channels{axis},'Interpreter','none');
    xlabel('Frequency [Hz]');
    if axis<=3
        ylabel('ASD [m/\surdHz]');
    else
        ylabel('ASD [rad/\surdHz]');
    end
    grid on; grid minor;
    if axis==1, legend('Location','southwest','FontSize',8); end
end
sgtitle(sprintf('Activity enhanced | no control | 10 kHz, %g s',duration_s));
annotation(fig,'textbox',[0.07,0.001,0.9,0.025], ...
    'String',sprintf('Welch: periodic Hann, 1,000,000 samples, 50%% overlap, constant detrend, density, mean | %d segments',segments), ...
    'EdgeColor','none','HorizontalAlignment','center','FontSize',9);
print(fig,destination,'-dpng','-r180');
close(fig);
end
