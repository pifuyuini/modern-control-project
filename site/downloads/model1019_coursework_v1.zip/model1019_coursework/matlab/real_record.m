function values = real_record(coefficients, n)
%REAL_RECORD Real time series from positive-frequency Q[k]/N coefficients.
% The provided DC is zero and the active band lies below Nyquist.
m = numel(coefficients);
spectrum = complex(zeros(n,1));
spectrum(1:m) = n*coefficients;
spectrum(n:-1:n-m+2) = conj(spectrum(2:m));
values = ifft(spectrum,'symmetric');
end
